import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blockedaccount',
  templateUrl: './blockedaccount.component.html',
 /* styleUrls: ['./blockedaccount.component.css']*/
})
export class BlockedaccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
