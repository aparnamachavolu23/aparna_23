import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Part1Component } from './head/part1/part1.component';
import { UserComponent } from './head/user/user.component';
import { LoginuComponent } from './login/loginu/loginu.component';
import { RegisterComponent } from './login/register/register.component';
import { SinglemediaComponent } from './media/singlemedia/singlemedia.component';
import { MultimediaComponent } from './media/multimedia/multimedia.component';
import { MymediaComponent } from './media/mymedia/mymedia.component';
import { GalleryComponent } from './media/gallery/gallery.component';
import { UploadmediaComponent } from './media/uploadmedia/uploadmedia.component';
import { AccountcComponent } from './account/accountc/accountc.component';
import { FollowersComponent } from './media/followers/followers.component';
import { NewsfeedComponent } from './account/newsfeed/newsfeed.component';
import { SearchComponent } from './account/search/search.component';

import { AccountupdateComponent } from './account/accountupdate/accountupdate.component';
import { LogoutComponent } from './account/logout/logout.component';
import { BlockedaccountComponent } from './account/blockedaccount/blockedaccount.component';

@NgModule({
  declarations: [
    AppComponent,
    Part1Component,
    UserComponent,
    LoginuComponent,
    RegisterComponent,
    SinglemediaComponent,
    MultimediaComponent,
    MymediaComponent,
    GalleryComponent,
    UploadmediaComponent,
    AccountcComponent,
    FollowersComponent,
    NewsfeedComponent,
    SearchComponent,
    
    AccountupdateComponent,
    
    LogoutComponent,
    
    BlockedaccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
