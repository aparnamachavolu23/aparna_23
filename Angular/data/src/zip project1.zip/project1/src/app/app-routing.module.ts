import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './login/register/register.component';
import { LoginuComponent } from './login/loginu/loginu.component';
import { MultimediaComponent } from './media/multimedia/multimedia.component';
import { SinglemediaComponent } from './media/singlemedia/singlemedia.component';
import { MymediaComponent } from './media/mymedia/mymedia.component';
import { GalleryComponent } from './media/gallery/gallery.component';
import { UploadmediaComponent } from './media/uploadmedia/uploadmedia.component';
import { AccountcComponent } from './account/accountc/accountc.component';
import { FollowersComponent } from './media/followers/followers.component';
import { NewsfeedComponent } from './account/newsfeed/newsfeed.component';
import { SearchComponent } from './account/search/search.component';
import { AccountupdateComponent } from './account/accountupdate/accountupdate.component';
import { LogoutComponent } from './account/logout/logout.component';
import { BlockedaccountComponent } from './account/blockedaccount/blockedaccount.component';

const routes: Routes = [
  {  path:"", redirectTo : "login", pathMatch: "full"},
  { path:"register", component: RegisterComponent},
  { path:"login", component: LoginuComponent},
  { path:"singlemedia",component :SinglemediaComponent},
  { path:"multimedia",component :MultimediaComponent},
  { path:"mymedia", component:MymediaComponent},
  { path:"gallery",component:GalleryComponent},
  { path:"uploadmedia",component:UploadmediaComponent},
  { path:"accountc",component:AccountcComponent},
  { path:"followers",component:FollowersComponent},
  { path:"newsfeed",component:NewsfeedComponent},
  { path:"search",component:SearchComponent},
  { path:"accountupdate",component:AccountupdateComponent},
  { path:"logout",component:LogoutComponent},
  { path:"blockedaccount",component:BlockedaccountComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
